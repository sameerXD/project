package com.ncu.validators;
import com.ncu.exception.*;
import java.io.*;
public class userNamevalidator
{
	public boolean usernameValidator(String username,String password)
	{
		try
		{
			Emptyusername(username);
			userLength(username);
			check(username);
			ValidPassword(password);
		}
		catch(EmptyUsernameException e)
		{
			System.out.println(e);
			return false;
		}
		catch(UserLengthException e)
		{
			System.out.println(e);
			return false;
		}
		catch(CheckException e)
		{
			System.out.println(e);	
			return false;
		}
		catch(InvalidPasswordException e)
		{
	    	System.out.println(e);
	    	return false;
		}
		return true;
	}
	void Emptyusername(String username) throws EmptyUsernameException
	{
		if(username=="")
			throw new EmptyUsernameException("Empty");
	}
	void userLength(String username) throws UserLengthException
	{
		int Length=20;
		if(username.length()>Length)
			throw new UserLengthException("Length more than 20");
	}
	void check(String username) throws CheckException
	{
        try
        { 
        	File f = new File("C:\\Users\\RITIKA\\Desktop\\Unguided Project\\configs\\constant\\username.csv");
	        FileReader fin = new FileReader(f);
		    BufferedReader bin= new BufferedReader(fin);
	 	    String sr;
			while((sr=bin.readLine())!=null)
			{
	            String[] dataLine = sr.split(",");
	            if(dataLine[0].equals(username))
	            	throw new CheckException("Already exist");
	        }
        }
        catch(IOException e)
        {
        	System.out.println(e);
        }
	}
	void ValidPassword(String password) throws InvalidPasswordException 
	{
		int PASSWORD_LENGTH = 8;
		boolean b=true;
		if (password.length()< PASSWORD_LENGTH)
		b=false;
		if(b==false)
			throw new InvalidPasswordException("Invalid Password");
	}
} 