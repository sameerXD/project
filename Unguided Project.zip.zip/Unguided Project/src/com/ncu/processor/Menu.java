package com.ncu.processor;
import com.ncu.exception.*;
import com.ncu.validators.*;
import java.util.*;
public class Menu 
{
    public void menushow(String username) 
    {
    Scanner sc= new Scanner(System.in);
    int num;
    System.out.println("Enter 1. To add something to do list\nEnter 2. To update to do list\nEnter 3. To delete something from to do list\n");
      num = sc.nextInt();
       switch(num)
        {
            case 1 : 
            {
            	    Add a=new Add();
                    a.addlist(username);
                    break;
            }
            case 2 :
            {
                    Update a =new Update();
                    a.updatelist(username);
           }
            case 3 :
            {
                    delete a=new delete();
                    a.deletelist(username);
                    break;
            }
            default:
                System.out.println("You have entered wrong choice");
                
        }
    }
}    
