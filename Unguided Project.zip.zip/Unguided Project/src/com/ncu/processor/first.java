package com.ncu.processor;
import com.ncu.exception.*;
import com.ncu.validators.*;
import java.util.*;
public class first
{
    public String[] firstpage() 
    {
    Scanner sc= new Scanner(System.in);
    int num;
    System.out.println("Enter 1. to Signup\nEnter 2. to Login");
      num = sc.nextInt();
      String te[]=new String[3];
       switch(num)
        {
            case 1 : 
            {
            	    signuppage s=new signuppage();
                    te=s.signup();
                    break;
            }
            case 2 :
            {
                    loginpage s=new loginpage();
                    te=s.checkLogin();
                    break;
            }
            default:
                System.out.println("You have entered wrong choice");
        }
        return te;
    }
}    