package com.ncu.processor;
import com.ncu.exception.*;
import com.ncu.validators.*;
import java.io.*;
import java.io.*;
import java.util.*;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class fileread
{
	public void read(String username) 
	{
		
		File f=null;
		Properties prop = new Properties();
		FileInputStream input=null; 
		Logger logger = Logger.getLogger(fileread.class);
		PropertyConfigurator.configure("C:\\Users\\tusha_000\\Desktop\\ultimate\\Unguided Project\\configs\\logger\\logger.properties");
		try 
		{
			input = new FileInputStream("C:\\Users\\tusha_000\\Desktop\\ultimate\\Unguided Project\\configs\\constant\\exceptions.properties");
      prop.load(input);
	        String todo;
			todo="C:\\Users\\tusha_000\\Desktop\\ultimate\\Unguided Project\\todo"+username+".txt";
			f = new File(todo);
		    FileReader fin = new FileReader(f);
		    BufferedReader bin = new BufferedReader(fin);
			String a;
	        while((a=bin.readLine()) !=null)
	            System.out.println(a);
		}
	    catch(IOException e)
	    {logger.error("\n \n"+e+prop.getProperty("incorrect")+"\n");
	    	System.out.println(e);
	    }
    }
}