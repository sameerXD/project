package com.ncu.exception;
	public class EmptyUsernameException extends Exception{
		public EmptyUsernameException(String s){
			super(s);
		}
	}
