package com.ncu.exception;
public class InvalidPasswordException extends Exception{
	public InvalidPasswordException(String s){
		super(s);
	}
}