package com.ncu.exception;
public class UserLengthException extends Exception{
	public UserLengthException(String s){
		super(s);
	}
}