package com.ncu.exception;
public class CheckException extends Exception
{
	public CheckException(String s){
		super(s);
	}
}